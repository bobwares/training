97879878

# BTR Commons


The BTR Commons is a set of components that can be used as a foundation for Java Spring based apps.  

BTR Commons contains the following components:
- Registry
- ObjectConverter
- Swagger Markdown 
- Rest Service Gateway

Refer to BTR Showcase for a usage examples of the BTR Commons components.


###Usage

The jar file will be deployed to the Climate internal repository.  Add the following to your Maven's repositories section 
to point to the repository.  
 
  ~~~~
      <repository>
        <id>climate-repo</id>
        <name>climate-releases</name>
        <url>https://bin.tcc.li/libs-release-local</url>
      </repository>
   ~~~~
 

 The jar can be added to your project by including the following dependency to your POM. 

~~~
  <dependency>
    <groupId>com.climate.btr</groupId>
    <artifactId>common</artifactId>
    <version>0.0.1-SNAPSHOT</version>
  </dependency>
~~~

To enable to components add the @Common annotation to the Spring Application class or a Spring Java based configuration class.

~~~

@Common
@SpringBootApplication
public class ShowcaseApplication {

  public static void main(String[] args) {
    SpringApplication.run(ShowcaseApplication.class, args);
  }
}

~~~

### Registry Component

The Registry Component provides the following:
- A Spring Singleton Component that wraps around Hashmap so that it can be injected into multiple Spring Beans.
- A get value method that returns values wrapped in an java.util.Optional.
- Framework for loading data into the Registry from resource files. 


### Usage

  - start with an class that you want to store in a registry.
  
  ~~~
  
  package com.climate.btr.showcase.registry.model;
  
  import lombok.Builder;
  import lombok.Value;
  
  @Value
  @Builder
  public class RegistryExamplePojo {
    
    private final String id;
    
    private final String code;
  
  }
  ~~~

  - configure a Registry Spring Bean Object for the desired type. 
  ~~~
  package com.climate.btr.showcase.registry.config;
  
  import com.climate.btr.common.registry.Registry;
  import com.climate.btr.showcase.registry.model.RegistryExamplePojo;
  import org.springframework.context.annotation.Bean;
  import org.springframework.context.annotation.Configuration;
  
  @Configuration
  public class RegistryExamplePojoConfiguration {
    
    @Bean
    public Registry<RegistryExamplePojo> registryExamplePojoRegistry() {
      Registry<RegistryExamplePojo> registryExamplePojoRegistry = new Registry<>();
  
      final RegistryExamplePojo registryExamplePojo = RegistryExamplePojo.builder().id("1").code("12345").build();
      
      // Add a value
      registryExamplePojoRegistry.put("key-1", registryExamplePojo);
  
      return registryExamplePojoRegistry;
    }
  
  }

  ~~~

  - Example usages in a Spring Service.
  
  ~~~
  package com.climate.btr.showcase.registry;
  
  import com.climate.btr.common.registry.Registry;
  import com.climate.btr.common.registry.exception.RegistryEntryNotFoundException;
  import com.climate.btr.showcase.registry.model.RegistryExamplePojo;
  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.stereotype.Service;
  
  @Service
  public class RegistryUsageExample {
  
    private final Registry<RegistryExamplePojo> registryExamplePojoRegistry;
  
    @Autowired
    public RegistryUsageExample(Registry<RegistryExamplePojo> registryExamplePojoRegistry) {
      this.registryExamplePojoRegistry = registryExamplePojoRegistry;
    }
  
    public String doSomethingWithTheRegistry(String id) {
      final RegistryExamplePojo registryExamplePojo = registryExamplePojoRegistry.get(id)
          .orElseThrow(RegistryEntryNotFoundException::new);
      return "Code is - " + registryExamplePojo.getCode() + ".";
    }
  }

  ~~~

  The real value of the registry is the ability to load large amounts of data from the application's resource directory after the Spring Context loads.  

1. create json data.
2. create pojo for the each record of data.
3. config registry
4. configure a resource objectConverter.

### ObjectConverter Component

The ObjectConverter Component is a convenience Spring Component that provides methods to serialize Java objects into JSON and 
deserialize JSON string into Java objects.  It uses the Jackson ObjectMapper as its' core object objectConverter.

### Swagger Markdown Component

The Swagger Markdown Component provides the following capabilities:
- API Info Plugin - Create the Swagger AppInfo Description text section into a markdown file.

- API Description Plugin - Move the API description section from the @ApiOperation in a Spring Controller to a markdown file.

#### Usage


## API Description Plugin

  
  ~~~
  @EnableSwagger2
  @Configuration
  public class SwaggerConfig {
  
    private final TypeResolver typeResolver;
  
    private final ApiInfoConfigBuilder apiInfoConfigBuilder;
  
    @Autowired
    public SwaggerConfig(
        TypeResolver typeResolver,
        ApiInfoConfigBuilder apiInfoConfigBuilder
    ) {
      this.typeResolver = typeResolver;
      this.apiInfoConfigBuilder = apiInfoConfigBuilder;
    }

  ...

  new Docket(DocumentationType.SWAGGER_2)
          .groupName("btr-showcase")
          .select()
          .paths(paths())
          .build()
          .apiInfo(apiInfo())
          .genericModelSubstitutes(ResponseEntity.class)
          .alternateTypeRules(newRule(typeResolver.resolve(DeferredResult.class,
              typeResolver.resolve(ResponseEntity.class, WildcardType.class)),
              typeResolver.resolve(WildcardType.class)))
          .useDefaultResponseMessages(false)
          .enableUrlTemplating(false);
  
  ~~~

### Rest Service Gateway

Encapsulates the repeatable operations that are performed when calling a REST service and marshalling the response. 

 - Host Service Discovery 
 - Construction of HTTP Headers, and Service Path Uri.
 - Perform HTTP call.
 - Check response for errors.
 - Convert JSON response in Java Object.

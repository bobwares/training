package com.climate.btr.common.swagger.impl;

import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.swagger.ApiInfoConfigBuilder;
import com.climate.btr.common.swagger.exception.ApiInfoException;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;

@Service
@DependsOn("registryBootstrap")
public class ApiInfoConfigBuilderImpl implements ApiInfoConfigBuilder {

  private Registry<String> registry;

  public ApiInfoConfigBuilderImpl(Registry<String> apiDescriptionRegistry) {
    this.registry = apiDescriptionRegistry;
  }

  @Override
  public ApiInfo build() {

    String apiInfoDescription = registry.get("apiInfo").
        orElseThrow(ApiInfoException::new);

    return new ApiInfoBuilder()
        .title("")
        .description(apiInfoDescription)
        .version("v1")
        .build();
  }
}

package com.climate.btr.common.gateway.client;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

public interface RestClient {

   <K> ResponseEntity<String> post(String serviceName, HttpHeaders httpHeaders, String serviceResourceUri, K postPayloadObject);

   <K> ResponseEntity<String> put(String serviceName, HttpHeaders httpHeaders, String serviceResourceUri, K putPayloadObject);

   ResponseEntity<String> get(String serviceName, HttpHeaders httpHeaders, String serviceResourceUri);

   ResponseEntity<String> delete(String serviceName, HttpHeaders httpHeaders, String serviceUrl);

   <K> ResponseEntity<String> delete(String serviceName, HttpHeaders httpHeaders, String serviceUrl, K deletePayloadObject);

   <K> ResponseEntity<String> patch(String serviceName, HttpHeaders httpHeaders, String serviceUrl, K patchPayloadObject);
}

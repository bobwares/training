package com.climate.btr.common.template.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@JsonDeserialize(builder = JsonTemplateGroupDefinition.JsonTemplateGroupDefinitionBuilder.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Value
public class JsonTemplateGroupDefinition {
  private final String key;
  private final String path;
  private final List<String> templates;

  @JsonPOJOBuilder(withPrefix = "")
  public static final class JsonTemplateGroupDefinitionBuilder {
  }
}

package com.climate.btr.common.gateway.config;

import com.climate.btr.common.gateway.client.impl.RestClientErrorHandler;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;


@Configuration
public class RestTemplateConfig {

  //https://stackoverflow.com/questions/41557069/how-do-i-implement-a-patch-executed-via-resttemplate
  // https://github.com/spring-projects/spring-framework/issues/19910

  @Bean
  protected RestTemplate restTemplate(RestTemplateBuilder builder) {
    HttpClient client = HttpClients.createDefault();
    return builder
        .requestFactory(() -> new BufferingClientHttpRequestFactory(new HttpComponentsClientHttpRequestFactory(client)))
        .errorHandler(new RestClientErrorHandler())
        .build();
  }

}

package com.climate.btr.common.registry.exception;

public class RegistryDataReaderException extends RuntimeException {

  private static final String MESSAGE = "Error parsing resource.";

  public RegistryDataReaderException() {
    super(MESSAGE);
  }

  public RegistryDataReaderException(String message) {
    super(message);
  }

  public RegistryDataReaderException(String message, Throwable cause) {
    super(message, cause);
  }

}

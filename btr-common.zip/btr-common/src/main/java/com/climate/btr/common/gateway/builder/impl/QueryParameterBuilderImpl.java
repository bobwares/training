package com.climate.btr.common.gateway.builder.impl;

import com.climate.btr.common.gateway.builder.QueryParameterBuilder;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

/**
 *
 * Takes a list of service parameters and appends together a string
 * of query named value pairs.  Operates on service parameters with in field
 * value of “QUERY”.
 *
 */
@Service
public class QueryParameterBuilderImpl implements QueryParameterBuilder {

  @Override
  public MultiValueMap<String, String> build(List<ServiceParameter> serviceParameters) {
    MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
    serviceParameters.stream().filter(serviceParameter -> serviceParameter.getIn().equals(ServiceParameterTypeEnum.QUERY)).forEach(serviceParameter ->
      queryParams.add(serviceParameter.getName(),serviceParameter.getValue()));
    return queryParams;
  }
}

package com.climate.btr.common.gateway.builder;

import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;

public interface PathParameterBuilder {
  String build(List<ServiceParameter> serviceParameters);
}

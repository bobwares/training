package com.climate.btr.common.gateway.http;

/**
 *
 * Common set of HTTP Header Keys
 *
 */

public enum HttpHeaderKeyEnum {
  X_HTTP_USER_EMAIL("x-http-user-email"),
  SERVICE_NAME("SERVICE_NAME"),
  TALUS_OUTGOING_CALLER_ID("talus"),
  X_HTTP_CALLER_ID("x-http-caller-id"),
  X_AUTHENTICATED_USER_UUID("x-authenticated-user-uuid"),
  X_AUTHENTICATED_USER_ID("x-authenticated-user-id"),
  X_HTTP_REQUEST_ID("x-http-request-id"),
  X_USER_ID("x-user-id"),
  REQUEST_ID_PREFIX("Talus-deploymentTests-");

  private final String value;

  HttpHeaderKeyEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

}

package com.climate.btr.common.objectcache;

import static java.nio.charset.StandardCharsets.UTF_8;

import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.registry.exception.RegistryDataReaderException;
import com.climate.btr.common.template.model.JsonTemplateDefinition;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class JsonTemplateCache implements ObjectCache<InputStreamReader>, ApplicationContextAware {

  private ApplicationContext applicationContext;

  private final Registry<JsonTemplateDefinition> jsonTemplateDefinitionRegistry;

  @Autowired
  public JsonTemplateCache(Registry<JsonTemplateDefinition> jsonTemplateDefinitionRegistry) {
    this.jsonTemplateDefinitionRegistry = jsonTemplateDefinitionRegistry;
  }

  @Override
  public Optional<InputStreamReader> get(String key) {
    JsonTemplateDefinition jsonTemplateDefinition = jsonTemplateDefinitionRegistry.get(key).orElseThrow(RegistryDataReaderException::new);

    if (jsonTemplateDefinition == null) {
      log.error("cannot determine template file for specified key " + key);
      return Optional.ofNullable(null);
    }

    Resource resource = applicationContext.getResource("classpath:" + jsonTemplateDefinition.getPath() + key + ".json");

    try {
      return Optional.ofNullable(new InputStreamReader(resource.getInputStream(), UTF_8));
    } catch (IOException e) {
      log.error("cannot determine template file for specified key " + key);
      return Optional.ofNullable(null);
    }
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    this.applicationContext = applicationContext;
  }
}

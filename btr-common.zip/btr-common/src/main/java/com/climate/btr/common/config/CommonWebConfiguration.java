package com.climate.btr.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"com.climate.btr.common"})
public class CommonWebConfiguration {

    @Bean
    public CommonWebMarker commonWebMarkerBean() {
        return new CommonWebMarker();
    }

    public class CommonWebMarker {
    }
}

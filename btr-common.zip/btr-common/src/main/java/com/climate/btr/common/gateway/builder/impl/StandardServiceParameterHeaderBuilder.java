package com.climate.btr.common.gateway.builder.impl;

import static com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum.HEADER;
import static com.climate.btr.common.gateway.http.HttpHeaderKeyEnum.X_AUTHENTICATED_USER_ID;
import static com.climate.btr.common.gateway.http.HttpHeaderKeyEnum.X_HTTP_REQUEST_ID;
import static com.climate.btr.common.gateway.http.HttpHeaderKeyEnum.X_USER_ID;

import com.climate.btr.common.gateway.builder.ServiceParameterHeaderBuilder;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

@Service
public class StandardServiceParameterHeaderBuilder implements ServiceParameterHeaderBuilder {

  @Override
  public Optional<List<ServiceParameter>> build(String userId) {

    List<ServiceParameter> serviceParameters = new ArrayList<>();

    serviceParameters.add(ServiceParameter.builder()
        .in(HEADER)
        .name(X_USER_ID.getValue())
        .value(userId)
        .required(true)
        .type("long")
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(HEADER)
        .name(X_AUTHENTICATED_USER_ID.getValue())
        .value(userId)
        .required(true)
        .type("String")
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(HEADER)
        .name(X_HTTP_REQUEST_ID.getValue())
        .value(MDC.get(X_HTTP_REQUEST_ID.getValue()))
        .required(true)
        .type("String")
        .build());

    return Optional.of(serviceParameters);
  }
}

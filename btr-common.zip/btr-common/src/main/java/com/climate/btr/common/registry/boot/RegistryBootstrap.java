package com.climate.btr.common.registry.boot;

import com.climate.btr.common.registry.RegistryLoader;
import java.util.Collection;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;

@Slf4j
public class RegistryBootstrap implements InitializingBean {

  private Collection<RegistryLoader> registryLoaders;

  public RegistryBootstrap(Collection<RegistryLoader> registryLoaders) {
    this.registryLoaders = registryLoaders;
  }

  @Override
  public void afterPropertiesSet() {
    log.info("Registry Loading is starting.");
    loadRegistries();
    log.info("Registries are loaded.");
  }

  private void loadRegistries() {
    for (RegistryLoader registryLoader : registryLoaders) {
      registryLoader.load();
    }
  }
}

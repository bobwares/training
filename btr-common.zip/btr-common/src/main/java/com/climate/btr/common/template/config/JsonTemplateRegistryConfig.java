package com.climate.btr.common.template.config;

import com.climate.btr.common.registry.Registry;
import java.io.InputStreamReader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JsonTemplateRegistryConfig {

//  @Bean
//  public Registry<InputStreamReader> jsonTemplateRegistry() {
//    return new Registry<>();
//  }

}

package com.climate.btr.common.template.loader;

import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.registry.RegistryLoader;
import com.climate.btr.common.registry.ResourceLoader;
import com.climate.btr.common.registry.ResourceReader;
import com.climate.btr.common.registry.exception.ResourceLoaderException;
import com.climate.btr.common.template.model.JsonTemplateDefinition;
import com.climate.btr.common.template.model.JsonTemplateGroupDefinition;
import java.util.Map;
import org.springframework.core.io.Resource;

public class JsonTemplateRegistryLoaderImpl implements RegistryLoader {

  private Registry<JsonTemplateGroupDefinition> jsonTemplateGroupDefinitionRegistry;
  private Registry<JsonTemplateDefinition> jsonTemplateDefinitionRegistry;

  private final ResourceLoader resourceLoader;
  private final ResourceReader resourceReader;

  private final String folder;
  private final String extension;

  public JsonTemplateRegistryLoaderImpl(
      ResourceLoader resourceLoader,
      ResourceReader resourceReader,
      String folder,
      String extension,
      Registry<JsonTemplateGroupDefinition> jsonTemplateGroupDefinitionRegistry,
      Registry<JsonTemplateDefinition> jsonTemplateDefinitionRegistry) {
    this.resourceLoader = resourceLoader;
    this.resourceReader = resourceReader;
    this.folder = folder;
    this.extension = extension;
    this.jsonTemplateGroupDefinitionRegistry = jsonTemplateGroupDefinitionRegistry;
    this.jsonTemplateDefinitionRegistry = jsonTemplateDefinitionRegistry;
  }

  @Override
  public void load() {
    final Map<String, Resource> resourceMap = resourceLoader.load(folder, extension);
    resourceReader.read(resourceMap);
    for (String key : jsonTemplateGroupDefinitionRegistry.keySet()) {
      JsonTemplateGroupDefinition jsonTemplateGroupDefinition = jsonTemplateGroupDefinitionRegistry.get(key).orElseThrow(ResourceLoaderException::new);
      for (String resourceName : jsonTemplateGroupDefinition.getTemplates()) {
        final JsonTemplateDefinition jsonTemplateDefinition = JsonTemplateDefinition.builder().key(resourceName).path(jsonTemplateGroupDefinition.getPath()).build();
        jsonTemplateDefinitionRegistry.put(resourceName, jsonTemplateDefinition);
      }
    }
  }
}

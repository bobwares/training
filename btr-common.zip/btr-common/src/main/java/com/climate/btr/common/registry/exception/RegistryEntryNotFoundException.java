package com.climate.btr.common.registry.exception;

public class RegistryEntryNotFoundException extends RuntimeException {

  private static final String MESSAGE = "Item not found in registry.";

  public RegistryEntryNotFoundException() {
    super(MESSAGE);
  }

  public RegistryEntryNotFoundException(String message) {
    super(message);
  }

  public RegistryEntryNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

}

package com.climate.btr.common.template.config;

import com.climate.btr.common.converter.ObjectConverter;
import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.registry.RegistryDataReader;
import com.climate.btr.common.registry.RegistryKeyBuilder;
import com.climate.btr.common.registry.RegistryLoader;
import com.climate.btr.common.registry.ResourceLoader;
import com.climate.btr.common.registry.ResourceReader;
import com.climate.btr.common.registry.impl.RegistryDataReaderImpl;
import com.climate.btr.common.registry.impl.RegistryKeyBuilderImpl;
import com.climate.btr.common.registry.impl.ResourceReaderImpl;
import com.climate.btr.common.template.loader.JsonTemplateRegistryLoaderImpl;
import com.climate.btr.common.template.model.JsonTemplateDefinition;
import com.climate.btr.common.template.model.JsonTemplateGroupDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JsonTemplateGroupDefinitionRegistryConfig {

  @Bean
  public Registry<JsonTemplateGroupDefinition> jsonTemplateGroupDefinitionRegistry() {
    return new Registry<>();
  }

  @Bean
  public RegistryDataReader<JsonTemplateGroupDefinition> jsonTemplateGroupDefinitionMapper(ObjectConverter objectConverter) {
    return new RegistryDataReaderImpl<>(objectConverter, JsonTemplateGroupDefinition.class);
  }
  @Bean
  public RegistryKeyBuilder<JsonTemplateGroupDefinition> jsonTemplateGroupDefinitionRegistryKeyBuilder() {
    return new RegistryKeyBuilderImpl<>();
  }

  @Bean
  public ResourceReader jsonTemplateGroupDefinitionResourceReader(
      Registry<JsonTemplateGroupDefinition> registry,
      RegistryDataReader<JsonTemplateGroupDefinition> jsonTemplateGroupDefinitionResourceMapper,
      RegistryKeyBuilder<JsonTemplateGroupDefinition> registryKeyBuilder
  ) {
    return new ResourceReaderImpl<>(registry, jsonTemplateGroupDefinitionResourceMapper, registryKeyBuilder);
  }

  @Bean
  public RegistryLoader jsonTemplateGroupDefinitionRegistryLoader(
      ResourceLoader resourceLoader,
      ResourceReader jsonTemplateGroupDefinitionResourceReader,
      Registry<JsonTemplateGroupDefinition> jsonTemplateGroupDefinitionRegistry,
      Registry<JsonTemplateDefinition> jsonTemplateDefinitionRegistry) {
    return new JsonTemplateRegistryLoaderImpl(
        resourceLoader,
        jsonTemplateGroupDefinitionResourceReader,
        "template-group-definitions",
        "json",
        jsonTemplateGroupDefinitionRegistry,
        jsonTemplateDefinitionRegistry);
  }

}

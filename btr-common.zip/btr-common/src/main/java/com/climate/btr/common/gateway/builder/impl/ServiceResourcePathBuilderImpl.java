package com.climate.btr.common.gateway.builder.impl;

import com.climate.btr.common.gateway.builder.PathParameterBuilder;
import com.climate.btr.common.gateway.builder.QueryParameterBuilder;
import com.climate.btr.common.gateway.builder.ServiceResourcePathBuilder;
import com.climate.btr.common.gateway.discovery.DiscoveryServiceClient;
import com.climate.btr.common.gateway.exception.ServiceGatewayException;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;


/**
 *
 * Encapsulates the following components:
 *  - Host Discovery Service
 *  - Path Parameter Builder
 *  - Query Parameter Builder
 *
 *  Constructs the Service Uri for a REST call from values of host, the API path, and the required path and query parameters.
 *
 */

@Slf4j
public final class ServiceResourcePathBuilderImpl implements ServiceResourcePathBuilder {

  private final DiscoveryServiceClient discoveryServiceClient;

  private final PathParameterBuilder pathParameterBuilder;

  private final QueryParameterBuilder queryParameterBuilder;

  public ServiceResourcePathBuilderImpl(
      DiscoveryServiceClient discoveryServiceClient,
      PathParameterBuilder pathParameterBuilder,
      QueryParameterBuilder queryParameterBuilder) {
    this.discoveryServiceClient = discoveryServiceClient;
    this.pathParameterBuilder = pathParameterBuilder;
    this.queryParameterBuilder = queryParameterBuilder;
  }

  /**
   *
   * Constructs the Service Uri with Host, path, path parameters and query parameters.
   *
   * @param serviceName
   * @param path
   * @param serviceParameters
   * @return  a string containing the host, the API path, and required path and query parameters.
   */
  @Override
  public String build(String serviceName, String path, List<ServiceParameter> serviceParameters) {
    String host = discoveryServiceClient.getHost(serviceName).orElseThrow(ServiceGatewayException::new);

    MultiValueMap<String, String> queryParams = queryParameterBuilder.build(serviceParameters);

    String pathParameters = pathParameterBuilder.build(serviceParameters);

    String serviceResourcePath = UriComponentsBuilder.fromUriString(host + "/" + path + pathParameters).queryParams(queryParams).build().encode().toUri().toString();
    log.info("serviceResourcePath = " + serviceResourcePath);
    return serviceResourcePath;
  }
}

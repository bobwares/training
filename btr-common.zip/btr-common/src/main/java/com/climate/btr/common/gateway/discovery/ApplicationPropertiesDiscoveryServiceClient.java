package com.climate.btr.common.gateway.discovery;

import java.util.Optional;

public class ApplicationPropertiesDiscoveryServiceClient implements DiscoveryServiceClient {

  private final PropertyFileHostRegistry propertyFileHostRegistry;

  public ApplicationPropertiesDiscoveryServiceClient(PropertyFileHostRegistry propertyFileHostRegistry) {
    this.propertyFileHostRegistry = propertyFileHostRegistry;
  }

  @Override
  public Optional<String> getHost(String serviceKey) {
    return propertyFileHostRegistry.getHost(serviceKey);
  }
}

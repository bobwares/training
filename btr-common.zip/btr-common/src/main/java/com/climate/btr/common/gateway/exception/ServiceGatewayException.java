package com.climate.btr.common.gateway.exception;

public class ServiceGatewayException extends RuntimeException {
  private static final String MESSAGE = "Error accessing REST Service.";

  public ServiceGatewayException() {
    super(MESSAGE);
  }

  public ServiceGatewayException(String message) {
    super(message);
  }

  public ServiceGatewayException(String message, Throwable cause) {
    super(message, cause);
  }
}

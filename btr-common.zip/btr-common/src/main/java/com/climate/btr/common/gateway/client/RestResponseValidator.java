package com.climate.btr.common.gateway.client;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

public interface RestResponseValidator {

  void validate(String serviceName, HttpMethod httpMethod, String path, ResponseEntity<String> responseEntity);

}

package com.climate.btr.common.registry;

public interface RegistryLoader {

  void load();

}

package com.climate.btr.common.gateway.discovery;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *
 *  Java based configuration for Application Properties Discovery Service.
 *
 */

@Configuration
public class ApplicationPropertiesDiscoveryServiceConfiguration {

  @Bean
  public DiscoveryServiceClient applicationPropertiesDiscoveryServiceClient(PropertyFileHostRegistry propertyFileHostRegistry) {
    return new ApplicationPropertiesDiscoveryServiceClient(propertyFileHostRegistry);
  }

}

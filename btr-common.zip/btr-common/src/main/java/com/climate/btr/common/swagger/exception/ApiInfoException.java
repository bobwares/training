package com.climate.btr.common.swagger.exception;

public class ApiInfoException extends RuntimeException {

  private static final String MESSAGE = "Unable to load Swagger API Info from apiInfo.md.";

  public ApiInfoException() {
    super(MESSAGE);
  }

  ApiInfoException(String message) {
    super(message);
  }

  public ApiInfoException(String message, Throwable cause) {
    super(message, cause);
  }
}
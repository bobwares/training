package com.climate.btr.common.gateway.config;

import static org.springframework.http.MediaType.APPLICATION_JSON;

import com.climate.btr.common.gateway.builder.HttpHeaderBuilder;
import com.climate.btr.common.gateway.builder.PathParameterBuilder;
import com.climate.btr.common.gateway.builder.QueryParameterBuilder;
import com.climate.btr.common.gateway.builder.ServiceResourcePathBuilder;
import com.climate.btr.common.gateway.builder.impl.HttpHeaderBuilderImpl;
import com.climate.btr.common.gateway.builder.impl.ServiceResourcePathBuilderImpl;
import com.climate.btr.common.gateway.discovery.DiscoveryServiceClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;

/**
 *
 *  Java Configuration class for the Service Resource Path Builder.
 *
 */

@Configuration
public class ServiceResourcePathBuilderConfiguration {

  @Bean
  public ServiceResourcePathBuilder serviceResourcePathBuilder(
      DiscoveryServiceClient applicationPropertiesDiscoveryServiceClient,
      PathParameterBuilder pathParameterBuilder,
      QueryParameterBuilder queryParameterBuilder) {
    return new ServiceResourcePathBuilderImpl(
        applicationPropertiesDiscoveryServiceClient,
        pathParameterBuilder,
        queryParameterBuilder);
  }

  @Bean
  public HttpHeaderBuilder httpHeaderBuilder() {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(APPLICATION_JSON);
    return new HttpHeaderBuilderImpl(headers);
  }


}

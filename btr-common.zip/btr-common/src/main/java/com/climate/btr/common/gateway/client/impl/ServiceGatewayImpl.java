package com.climate.btr.common.gateway.client.impl;

import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.PATCH;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

import com.climate.btr.common.gateway.builder.HttpHeaderBuilder;
import com.climate.btr.common.gateway.builder.ServiceResourcePathBuilder;
import com.climate.btr.common.gateway.client.RestClient;
import com.climate.btr.common.gateway.client.RestResponseValidator;
import com.climate.btr.common.gateway.client.ServiceGateway;
import com.climate.btr.common.gateway.model.ServiceParameter;
import com.climate.btr.common.converter.ObjectConverterException;
import com.climate.btr.common.converter.ObjectConverter;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 *
 * The Service Gateway encapsulates the repeatable operations that are performed when calling a REST service and marshalling the response.
 *  - Host Service Discovery
 *  - Construction of HTTP Headers, and Service Path Uri.
 *  - Perform HTTP call.
 *  - Check response for errors.
 *  - Convert JSON response in Java Object.
 *
 *  Header, path, and query parameters are passed to the Service Gateway through a list of Service Parameter objects.  The Service
 *  Parameters are modeled after Swagger's parameter definition.
 *
 */


@Slf4j
public final class ServiceGatewayImpl implements ServiceGateway {

  private final RestResponseValidator restResponseValidator;

  private final ObjectConverter objectConverter;

  private final RestClient restClient;

  private final ServiceResourcePathBuilder serviceResourcePathBuilder;

  private final HttpHeaderBuilder headerBuilder;

  private final String serviceName;

  public ServiceGatewayImpl(
      String serviceName,
      RestResponseValidator restResponseValidator,
      ObjectConverter objectConverter,
      RestClient restClient,
      ServiceResourcePathBuilder serviceResourcePathBuilder,
      HttpHeaderBuilder headerBuilder) {
    this.restResponseValidator = restResponseValidator;
    this.objectConverter = objectConverter;
    this.restClient = restClient;
    this.serviceResourcePathBuilder = serviceResourcePathBuilder;
    this.headerBuilder = headerBuilder;
    this.serviceName = serviceName;
  }

  @Override
  public <T, K> Optional<T> post(String path, K postPayloadObject, Class<T> resultType, List<ServiceParameter> serviceParameters) {
    String serviceResourcePath = serviceResourcePathBuilder.build(serviceName, path, serviceParameters);

    logCall(serviceResourcePath, POST);

    HttpHeaders headers = headerBuilder.build(serviceName, serviceParameters);

    ResponseEntity<String> responseEntity = restClient.post(serviceName, headers, serviceResourcePath, postPayloadObject);

    restResponseValidator.validate(serviceName, POST, serviceResourcePath, responseEntity);

    if (resultType.isInstance(responseEntity.getBody())) {
      return Optional.ofNullable((T) responseEntity.getBody());
    }

    return Optional.ofNullable(objectConverter.jsonToObject(responseEntity.getBody(), resultType)).orElseThrow(ObjectConverterException::new);
  }

  @Override
  public <T, K> Optional<T> put(String path, K putPayloadObject, Class<T> resultType, List<ServiceParameter> serviceParameters) {
    String serviceResourcePath = serviceResourcePathBuilder.build(serviceName, path, serviceParameters);

    logCall(serviceResourcePath, PUT);

    HttpHeaders headers = headerBuilder.build(serviceName, serviceParameters);

    ResponseEntity<String> responseEntity = restClient.put(serviceName, headers, serviceResourcePath, putPayloadObject);

    restResponseValidator.validate(serviceName, PUT, serviceResourcePath, responseEntity);

    if (resultType.isInstance(responseEntity.getBody())) {
      return Optional.ofNullable((T) responseEntity.getBody());
    }

    return Optional.ofNullable(objectConverter.jsonToObject(responseEntity.getBody(), resultType)).orElseThrow(ObjectConverterException::new);
  }

  @Override
  public <T> Optional<T> get(String path, Class<T> resultType, List<ServiceParameter> serviceParameters) {
    String serviceResourcePath = serviceResourcePathBuilder.build(serviceName, path, serviceParameters);

    logCall(serviceResourcePath, GET);

    HttpHeaders headers = headerBuilder.build(serviceName, serviceParameters);

    ResponseEntity<String> responseEntity = restClient.get(serviceName, headers, serviceResourcePath);

    restResponseValidator.validate(serviceName, GET, serviceResourcePath, responseEntity);

    if (resultType.isInstance(responseEntity.getBody())) {
      return Optional.ofNullable((T) responseEntity.getBody());
    }

    return Optional.ofNullable(objectConverter.jsonToObject(responseEntity.getBody(), resultType)).orElseThrow(ObjectConverterException::new);
  }

  @Override
  public Optional<String> delete(String path, List<ServiceParameter> serviceParameters) {
    String serviceResourcePath = serviceResourcePathBuilder.build(serviceName, path, serviceParameters);

    logCall(serviceResourcePath, DELETE);

    HttpHeaders headers = headerBuilder.build(serviceName, serviceParameters);

    ResponseEntity<String> responseEntity = restClient.delete(serviceName, headers, serviceResourcePath);

    restResponseValidator.validate(serviceName, DELETE, serviceResourcePath, responseEntity);

    return Optional.ofNullable(responseEntity.getBody());
  }

  @Override
  public <K> Optional<String> delete(String path, K deletePayloadObject, List<ServiceParameter> serviceParameters) {
    String serviceResourcePath = serviceResourcePathBuilder.build(serviceName, path, serviceParameters);

    logCall(serviceResourcePath, DELETE);

    HttpHeaders headers = headerBuilder.build(serviceName, serviceParameters);

    ResponseEntity<String> responseEntity = restClient.delete(serviceName, headers, serviceResourcePath, deletePayloadObject);

    restResponseValidator.validate(serviceName, DELETE, serviceResourcePath, responseEntity);

    return Optional.ofNullable(responseEntity.getBody());
  }

  @Override
  public <K> void patch(String path, K patchPayloadObject, List<ServiceParameter> serviceParameters) {
    String serviceResourcePath = serviceResourcePathBuilder.build(serviceName, path, serviceParameters);

    logCall(serviceResourcePath, PATCH);

    HttpHeaders headers = headerBuilder.build(serviceName, serviceParameters);

    ResponseEntity<String> responseEntity = restClient.patch(serviceName, headers, serviceResourcePath, patchPayloadObject);

    restResponseValidator.validate(serviceName, PATCH, serviceResourcePath, responseEntity);

  }

  private void logCall(String serviceResourcePath, HttpMethod httpMethod) {
    log.info(serviceName + " {} {}", httpMethod, serviceResourcePath);
    //todo add debug level logging.
  }
}
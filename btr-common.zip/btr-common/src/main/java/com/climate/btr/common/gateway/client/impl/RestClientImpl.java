package com.climate.btr.common.gateway.client.impl;

import com.climate.btr.common.gateway.client.RestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 *  Uses Spring's RestTemplate module to implement POST, PUT, GET, and DELETE REST calls.
 *  The RestClient must be configured with a HttpHeaderBuilder to create the https headers for the call.
 *  see GrootServiceGatewayConfiguration.java for an example of how to configure the RestClientImpl.
 *
 */

@Slf4j
public class RestClientImpl implements RestClient {

  private final RestTemplate restTemplate;

  public RestClientImpl(RestTemplate restTemplate) {
    this.restTemplate = restTemplate;
  }

  @Override
  public <K> ResponseEntity<String> post(String serviceName, HttpHeaders httpHeaders, String serviceUrl, K postPayloadObject) {
    HttpEntity<?> httpEntity = new HttpEntity<>(postPayloadObject, httpHeaders);
    return this.restTemplate.exchange(serviceUrl, HttpMethod.POST, httpEntity, String.class);
  }

  @Override
  public <K> ResponseEntity<String> put(String serviceName, HttpHeaders httpHeaders, String serviceUrl, K putPayloadObject) {
    HttpEntity<?> httpEntity = new HttpEntity<>(putPayloadObject, httpHeaders);
    return this.restTemplate.exchange(serviceUrl, HttpMethod.PUT, httpEntity, String.class);
  }

  @Override
  public ResponseEntity<String> get(String serviceName, HttpHeaders httpHeaders, String serviceUrl) {
    HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
    return this.restTemplate.exchange(serviceUrl, HttpMethod.GET, httpEntity, String.class);
  }

  @Override
  public ResponseEntity<String> delete(String serviceName, HttpHeaders httpHeaders, String serviceUrl) {
    HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
    return this.restTemplate.exchange(serviceUrl, HttpMethod.DELETE, httpEntity, String.class);
  }

  @Override
  public <K> ResponseEntity<String> delete(String serviceName, HttpHeaders httpHeaders, String serviceUrl, K deletePayloadObject) {
    HttpEntity<?> httpEntity = new HttpEntity<>(deletePayloadObject, httpHeaders);
    return this.restTemplate.exchange(serviceUrl, HttpMethod.DELETE, httpEntity, String.class);
  }

  @Override
  public <K> ResponseEntity<String> patch(String serviceName, HttpHeaders httpHeaders, String serviceUrl, K patchPayloadObject) {
    HttpEntity<?> httpEntity = new HttpEntity<>(patchPayloadObject, httpHeaders);
    return this.restTemplate.exchange(serviceUrl, HttpMethod.PATCH, httpEntity, String.class);
  }
}

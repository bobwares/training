package com.climate.btr.common.gateway.discovery;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 *
 *  Loads application property files entries into Map using Spring @ConfigurationProperties
 *  annotation when the Spring context is loaded.
 *
 */

@Data
@ConfigurationProperties(prefix = "service-discovery-registry")
@Component
public class PropertyFileHostRegistry {

  private final Map<String, String> hosts = new HashMap<>();

  Optional<String> getHost(String key) {
    return Optional.ofNullable(hosts.get(key));
  }
}

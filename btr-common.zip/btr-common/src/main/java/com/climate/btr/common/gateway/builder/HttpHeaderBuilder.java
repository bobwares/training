package com.climate.btr.common.gateway.builder;

import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;
import org.springframework.http.HttpHeaders;

public interface HttpHeaderBuilder {

  HttpHeaders build(String serviceName, List<ServiceParameter> serviceParameters);

}

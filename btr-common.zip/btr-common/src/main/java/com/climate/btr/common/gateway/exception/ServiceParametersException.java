package com.climate.btr.common.gateway.exception;


public class ServiceParametersException extends RuntimeException {

  private static final String MESSAGE = "Unable to create headers for authenticated user.";

  public ServiceParametersException() {
    super(MESSAGE);
  }

  public ServiceParametersException(String message) {
    super(message);
  }

  public ServiceParametersException(String message, Throwable cause) {
    super(message, cause);
  }

}

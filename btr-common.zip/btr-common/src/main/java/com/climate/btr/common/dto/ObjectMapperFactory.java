package com.climate.btr.common.dto;

import com.climate.btr.common.converter.impl.ConfiguredObjectMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class ObjectMapperFactory {

  private static final ConfiguredObjectMapper mapper;

  static {
    mapper = new ConfiguredObjectMapper();
  }

  public static ObjectMapper getObjectMapper() {
    return mapper;
  }

}
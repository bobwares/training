package com.climate.btr.common.gateway.discovery;


import java.util.Optional;

public interface DiscoveryServiceClient {
    Optional<String> getHost(String serviceKey);
}

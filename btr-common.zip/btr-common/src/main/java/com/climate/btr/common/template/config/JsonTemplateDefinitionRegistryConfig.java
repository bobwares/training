package com.climate.btr.common.template.config;

import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.template.model.JsonTemplateDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JsonTemplateDefinitionRegistryConfig {

  @Bean
  public Registry<JsonTemplateDefinition> jsonTemplateDefinitionRegistry() {
    return new Registry<>();
  }

}

package com.climate.btr.common.security;

import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagement;
import com.amazonaws.services.simplesystemsmanagement.model.GetParametersRequest;
import com.amazonaws.services.simplesystemsmanagement.model.GetParametersResult;
import com.amazonaws.services.simplesystemsmanagement.model.InternalServerErrorException;
import com.amazonaws.services.simplesystemsmanagement.model.Parameter;
import java.util.Collections;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SsmParameterResolver {

  private static final String AWS_REGION = "us-east-1";

  private EnvChecker envChecker;

  private AWSSimpleSystemsManagement client;

  public SsmParameterResolver(EnvChecker envChecker, AWSSimpleSystemsManagement client){
    this.envChecker = envChecker;
    this.client = client;
  }

  private String getParam(String name) {
//    AWSSimpleSystemsManagementClientBuilder clientBuilder = AWSSimpleSystemsManagementClientBuilder.standard();
//    clientBuilder.setRegion(AWS_REGION);
//    AWSSimpleSystemsManagement client = clientBuilder.build();

    GetParametersRequest paramRequest = new GetParametersRequest();
    paramRequest.setNames(Collections.singletonList(name));

    try {
      GetParametersResult result = client.getParameters(paramRequest.withWithDecryption(true));
      List<Parameter> paramList = result.getParameters();
      if (paramList == null || paramList.size() == 0) {
        return null;
      } else {
        return paramList.get(0).getValue();
      }
    } catch (InternalServerErrorException e){
      throw new InternalServerErrorException("Unable to get parameters needed from AWS SSM");
    }
  }

  public boolean skipDecryption(){
    return envChecker.skipDecryption();
  }


  public String transformSsmParameter(String ssmParameter){
    return envChecker.transformSsmParameter(ssmParameter);
  }

  public String getSsmParameter(String ssmParameterString){
    log.info("retrieving SSM parameter for string : {}", ssmParameterString);
    String password;
    if (skipDecryption()) {
      password = ssmParameterString;
    }else {
      password = getParam(transformSsmParameter(ssmParameterString));
    }
    log.info("SSM Parameter retrieved successfully for String : {}", ssmParameterString);
    return password;
  }
}

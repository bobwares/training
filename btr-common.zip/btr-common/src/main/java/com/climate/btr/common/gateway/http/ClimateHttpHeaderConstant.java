package com.climate.btr.common.gateway.http;

public final class ClimateHttpHeaderConstant {

  public static final String X_HTTP_USER_EMAIL = "x-http-user-email";
  public static final String X_HTTP_USER_PASSWORD = "x-http-user-password";
  public static final String X_HTTP_REQUEST_ID = "x-http-request-id";
  public static final String X_HTTP_CALLER_ID = "x-http-caller-id";
  public static final String X_AUTHENTICATED_USER_UUID = "x-authenticated-user-uuid";
  public static final String X_USER_ID = "x-user-id";

  public static final String USER_AGENT = "User-Agent";
  public static final String SERVICE_NAME = "SERVICE_NAME";
  private ClimateHttpHeaderConstant() {
  }
}

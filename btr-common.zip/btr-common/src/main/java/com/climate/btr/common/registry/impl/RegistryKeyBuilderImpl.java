package com.climate.btr.common.registry.impl;

import com.climate.btr.common.registry.RegistryKeyBuilder;

public class RegistryKeyBuilderImpl<T> implements RegistryKeyBuilder<T> {

  @Override
  public String build(String resourceName, T item) {
    return resourceName;
  }
}

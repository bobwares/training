package com.climate.btr.common.gateway.builder;

import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;
import org.springframework.util.MultiValueMap;

public interface QueryParameterBuilder {
  MultiValueMap<String, String> build(List<ServiceParameter> serviceParameters);
}

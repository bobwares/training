package com.climate.btr.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.Serializable;

public class BaseDto implements Serializable {

  private String toStr() {
    try {
      return ObjectMapperFactory.getObjectMapper().writeValueAsString(this);
    } catch (JsonProcessingException jpe) {
      return super.toString();
    }
  }

  @Override
  @JsonIgnore
  public String toString() {
    return toStr();
  }

  public String toJson() {
    return toStr();
  }

}

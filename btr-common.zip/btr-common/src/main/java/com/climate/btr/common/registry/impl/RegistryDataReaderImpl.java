package com.climate.btr.common.registry.impl;

import com.climate.btr.common.converter.ObjectConverter;
import com.climate.btr.common.registry.RegistryDataReader;
import java.io.InputStream;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;

@Slf4j
public class RegistryDataReaderImpl<T> implements RegistryDataReader<T> {

  private final ObjectConverter objectMapper;

  private final Class<T> registryType;

  public RegistryDataReaderImpl(ObjectConverter objectMapperImpl, Class<T> registryType) {
    this.objectMapper = objectMapperImpl;
    this.registryType = registryType;
  }

  @Override
  public Optional<T> resourceToObject(Resource resource) {
    try {
      InputStream inputStream = resource.getInputStream();
      return objectMapper.jsonToObject(inputStream, registryType);
    }
    catch (Exception e) {
      log.error("Failed to load configuration for {}", resource, e);
      return Optional.empty();
    }
  }
}

package com.climate.btr.common.swagger.registry.mapper;

import com.climate.btr.common.registry.RegistryDataReader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;

@Slf4j
public class ApiDescriptionResourceMapper implements RegistryDataReader<String> {

  @Override
  public Optional<String> resourceToObject(Resource resource) {

    try {
      InputStream inputStream = resource.getInputStream();

      BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
      StringBuilder result = new StringBuilder();
      String line;
      while ((line = br.readLine()) != null) {
        result.append(line).append('\n');
      }

      return Optional.of(result.toString());
    }
    catch (Exception e) {
      log.error("Failed to load configuration for {}", resource.getFilename(), e);
      return Optional.empty();
    }
  }
}

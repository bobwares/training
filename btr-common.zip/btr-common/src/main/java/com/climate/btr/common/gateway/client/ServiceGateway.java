package com.climate.btr.common.gateway.client;

import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;

public interface ServiceGateway {

  <T, K> Optional<T> post(String path, K postPayloadObject, Class<T> resultType, List<ServiceParameter> serviceParameters);

  <T, K> Optional<T> put(String path, K putPayloadObject, Class<T> resultType, List<ServiceParameter> serviceParameters);

  <T> Optional<T> get(String path, Class<T> resultType, List<ServiceParameter> serviceParameters);

  Optional<String> delete(String path, List<ServiceParameter> serviceParameters);

  <K> Optional<String> delete(String path, K deletePayloadObject, List<ServiceParameter> serviceParameters);

  <K> void patch(String path, K patchPayloadObject, List<ServiceParameter> serviceParameters);

}

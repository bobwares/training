package com.climate.btr.common.gateway.builder;

import com.climate.btr.common.gateway.model.RestErrorAdapter;

public interface RestErrorBuilder {

  RestErrorAdapter build(String responseBody);

}

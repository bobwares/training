package com.climate.btr.common.gateway.model;

import com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum;
import java.util.List;
import lombok.Builder;
import lombok.Data;

/**
 *
 * Pojo that contains a parameter to be used when constructing a REST API call.  Modeled after Swagger parameters.
 *
 */

@Builder
@Data
public final class ServiceParameter {
  private ServiceParameterTypeEnum in;
  private String name;
  private boolean required;
  private boolean sticky;
  private String type;
  private String value;

  public void setValue(String value) {
    this.value = value;
  }

  public static String getValue(List<ServiceParameter> serviceParameters, String name) {
    return serviceParameters.stream().filter(serviceParameter -> serviceParameter.getName().equals(name))
        .map(ServiceParameter::getValue)
        .findFirst().orElse("");
  }
  public static ServiceParameter getServiceParameter(List<ServiceParameter> serviceParameters, String name) {
    return serviceParameters.stream().filter(serviceParameter -> serviceParameter.getName().equals(name))
        .findFirst().orElse(null);
  }
}

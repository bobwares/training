package com.climate.btr.common.security;

public interface EnvChecker {

  boolean skipDecryption();
  String transformSsmParameter(String ssmParameter);
}

package com.climate.btr.common.gateway.model;

public interface RestErrorAdapter {
  String getSource();
  String getErrorMessage();
  String getErrorId();
  String getErrorCode();
}

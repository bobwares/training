package com.climate.btr.common.template.model;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class JsonTemplateDefinition {
  private final String key;
  private final String path;
}

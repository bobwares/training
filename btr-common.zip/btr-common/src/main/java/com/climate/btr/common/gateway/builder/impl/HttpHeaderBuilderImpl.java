package com.climate.btr.common.gateway.builder.impl;

import static com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum.HEADER;
import static com.climate.btr.common.gateway.http.ClimateHttpHeaderConstant.SERVICE_NAME;

import com.climate.btr.common.gateway.builder.HttpHeaderBuilder;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;
import org.springframework.http.HttpHeaders;

/**
 *
 *  Constructs the Spring HttpHeaders from a list of service header parameters.  Can also be initialized
 *  with a set of HttpHeaders when configured.
 *
 */
public class HttpHeaderBuilderImpl implements HttpHeaderBuilder {

  private final HttpHeaders commonHttpHeaders;

  public HttpHeaderBuilderImpl(HttpHeaders commonHttpHeaders) {
    this.commonHttpHeaders = commonHttpHeaders;
  }

  @Override
  public HttpHeaders build(String serviceName, List<ServiceParameter> serviceParameters) {
    HttpHeaders headers = new HttpHeaders();

    headers.putAll(commonHttpHeaders);

    serviceParameters.stream().filter(serviceParameter -> serviceParameter.getIn().equals(HEADER))
        .forEach(serviceParameter -> headers.add(serviceParameter.getName(),serviceParameter.getValue()));

    headers.add(SERVICE_NAME, serviceName);

    return headers;
  }

}


package com.climate.btr.common.gateway.builder;

import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;
import java.util.Optional;

public interface ServiceParameterHeaderBuilder {

  Optional<List<ServiceParameter>> build(String userId);

}

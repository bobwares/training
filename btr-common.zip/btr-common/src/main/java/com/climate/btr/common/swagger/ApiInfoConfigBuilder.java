package com.climate.btr.common.swagger;

import springfox.documentation.service.ApiInfo;

public interface ApiInfoConfigBuilder {

  ApiInfo build();

}

package com.climate.btr.common.gateway.client.impl;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

import com.climate.btr.common.gateway.builder.RestErrorBuilder;
import com.climate.btr.common.gateway.client.RestResponseValidator;
import com.climate.btr.common.gateway.model.RestErrorAdapter;
import com.climate.btr.common.gateway.exception.DownstreamServiceException;
import com.climate.btr.common.gateway.exception.RestClientException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 *
 *  Checks the response from a REST API call for errors.
 *
 */


@Slf4j
public class RestResponseValidatorImpl implements RestResponseValidator {
  private static final HttpStatus[] acceptableSuccessfulResponseCodes = {OK, CREATED};

  private static final String EMPTY_JSON_TEXT = "{}";

  private final RestErrorBuilder restErrorBuilder;

  public RestResponseValidatorImpl(RestErrorBuilder restErrorBuilder) {
    this.restErrorBuilder = restErrorBuilder;
  }

  @SuppressWarnings("Duplicates")
  @Override
  public void validate(String serviceName, HttpMethod httpMethod, String serviceUri, ResponseEntity<String> responseEntity) {
    String responseBody = (responseEntity.getBody() == null || responseEntity.getBody().isEmpty()) ? EMPTY_JSON_TEXT : responseEntity.getBody();
    if (RestClientErrorHandler.hasError(responseEntity.getStatusCode())) {
      log.error("Call failed for URL : {} with Status Code {} ", serviceUri, responseEntity.getStatusCode());

      RestErrorAdapter errorHandler = restErrorBuilder.build(responseBody);

      if (RestClientErrorHandler.hasClientError(responseEntity.getStatusCode())) {
        log.error("Talus received error : {} with message : {}", responseEntity.getStatusCode(), errorHandler.getErrorMessage());
        throw new RestClientException(errorHandler.getSource(), errorHandler.getErrorId(), errorHandler.getErrorCode(),
            errorHandler.getErrorMessage(), responseEntity.getStatusCode(), responseEntity.getHeaders());
      } else {
        log.error("Talus received error : {} with message : {}", responseEntity.getStatusCode(), errorHandler.getErrorMessage());
        throw new DownstreamServiceException(errorHandler.getSource(), errorHandler.getErrorId(), errorHandler.getErrorCode(),
            errorHandler.getErrorMessage(), responseEntity.getStatusCode(), responseEntity.getHeaders());
      }
    }
  }
}

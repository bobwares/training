package com.climate.btr.common.swagger.registry.config;

import com.climate.btr.common.converter.ObjectConverter;
import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.registry.RegistryKeyBuilder;
import com.climate.btr.common.registry.RegistryLoader;
import com.climate.btr.common.registry.ResourceLoader;
import com.climate.btr.common.registry.RegistryDataReader;
import com.climate.btr.common.registry.ResourceReader;
import com.climate.btr.common.registry.impl.RegistryKeyBuilderImpl;
import com.climate.btr.common.registry.impl.RegistryLoaderImpl;
import com.climate.btr.common.registry.impl.ResourceReaderImpl;
import com.climate.btr.common.swagger.registry.mapper.ApiDescriptionResourceMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApiDescriptionRegistryConfig {

  @Bean
  public Registry<String> apiDescriptionRegistry() {
    return new Registry<>();
  }

  @Bean
  public RegistryDataReader<String> apiDescriptionResourceMapper() {
    return new ApiDescriptionResourceMapper();
  }

  @Bean
  public RegistryKeyBuilder<String> apiDescriptionRegistryKeyBuilder() {
    return new RegistryKeyBuilderImpl<>();
  }

  @Bean
  public ResourceReader apiDescriptionResourceReader(
      Registry<String> apiDescriptionRegistry,
      RegistryDataReader<String> apiDescriptionResourceMapper,
      RegistryKeyBuilder<String> registryKeyBuilder
  ) {
    return new ResourceReaderImpl<>(apiDescriptionRegistry, apiDescriptionResourceMapper, registryKeyBuilder);
  }

  @Bean
  public RegistryLoader apiDescriptionRegistryLoader(
      ResourceLoader resourceLoader,
      ResourceReader apiDescriptionResourceReader,
      @Value("${swagger.markdown.foler:swagger}") String folder,
      @Value("${swagger.markdown.extention:md}") String extention) {
    return new RegistryLoaderImpl(
        resourceLoader,
        apiDescriptionResourceReader,
        folder,
        extention);
  }

}

package com.climate.btr.common.gateway.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

public class RestClientException extends RuntimeException {

  private final String source;
  private final String errorId;
  private final String errorCode;
  private final HttpStatus httpStatus;
  private final HttpHeaders httpHeaders;

  public RestClientException(String source, String errorId, String errorCode, String errorMsg, HttpStatus httpStatus, HttpHeaders httpHeaders) {

    super(errorMsg);
    this.source = source;
    this.errorId = errorId;
    this.errorCode = errorCode;
    this.httpStatus = httpStatus;
    this.httpHeaders = httpHeaders;
  }

  public RestClientException(HttpStatus httpStatus, HttpHeaders httpHeaders, String errorCode, String errorMsg) {
    super(errorMsg);
    this.httpStatus = httpStatus;
    this.httpHeaders = httpHeaders;
    this.errorCode = errorCode;
    this.source = null;
    this.errorId = null;
  }

  public HttpStatus getHttpStatus() {
    return httpStatus;
  }

  public HttpHeaders getHttpHeaders() {
    return httpHeaders;
  }

  public String getErrorCode() {
    return errorCode;
  }

  public String getSource() {
    return source;
  }

  public String getErrorId() {
    return errorId;
  }
}

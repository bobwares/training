package com.climate.btr.common.objectcache;

import java.util.Optional;

public interface ObjectCache<T> {

  Optional<T> get(String key);

}

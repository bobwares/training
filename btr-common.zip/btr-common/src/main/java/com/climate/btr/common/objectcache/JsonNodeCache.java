package com.climate.btr.common.objectcache;

import com.climate.btr.common.converter.ObjectConverter;
import com.climate.btr.common.converter.ObjectConverterException;
import com.fasterxml.jackson.databind.JsonNode;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class JsonNodeCache implements ObjectCache<JsonNode> {

  private final ObjectConverter objectConverter;

  private final JsonTemplateCache jsonTemplateCache;

  @Autowired
  public JsonNodeCache(ObjectConverter objectConverter, JsonTemplateCache jsonTemplateCache) {
    this.objectConverter = objectConverter;
    this.jsonTemplateCache = jsonTemplateCache;
  }

  private Map<String, JsonNode> jsonNodeMap = new HashMap<>();

  @Override
  public Optional<JsonNode> get(final String key)  {

    log.debug("if the node has already been created return it to the caller.");
    JsonNode jsonNode = jsonNodeMap.get(key);
    if (jsonNode != null) {
      return Optional.ofNullable(jsonNode);
    }

    log.debug("next check if the key is valid.");
    InputStreamReader inputStreamReader = jsonTemplateCache.get(key).orElseThrow(ObjectConverterException::new);

    try {
      jsonNode = objectConverter.jsonToObject(inputStreamReader, JsonNode.class).orElseThrow(IOException::new);
    } catch (IOException e) {
      log.error("cannot determine sampleFieldsIn file for specified country code " + key);
      return Optional.empty();
    }
    jsonNodeMap.put(key, jsonNode);
    return Optional.ofNullable(jsonNode);
  }
}
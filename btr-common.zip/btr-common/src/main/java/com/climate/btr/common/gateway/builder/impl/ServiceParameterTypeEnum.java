package com.climate.btr.common.gateway.builder.impl;


/**
 *
 * Enumeration of support Service Parameter "in" values.
 *
 */
public enum ServiceParameterTypeEnum {
  HEADER,
  PATH,
  QUERY
}

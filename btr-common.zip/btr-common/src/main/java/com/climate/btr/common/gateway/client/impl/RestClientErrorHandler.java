package com.climate.btr.common.gateway.client.impl;

import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

@Slf4j
public class RestClientErrorHandler implements ResponseErrorHandler {

  @Override
  public void handleError(ClientHttpResponse resp) throws IOException {
    log.info("Response error: {} {}", resp.getStatusCode(), resp.getStatusText());
  }

  @Override
  public boolean hasError(ClientHttpResponse response) throws IOException {
    return hasError(response.getStatusCode());
  }

  public boolean hasClientError(ClientHttpResponse response) throws IOException {
    return hasClientError(response.getStatusCode());
  }

  public static boolean hasError(HttpStatus status) {
    HttpStatus.Series series = status.series();
    return HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR.equals(series);
  }

  public static boolean hasClientError(HttpStatus status) {
    HttpStatus.Series series = status.series();
    return HttpStatus.Series.CLIENT_ERROR.equals(series);
  }


}
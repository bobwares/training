package com.climate.btr.common.gateway.builder.impl;

import static com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum.PATH;

import com.climate.btr.common.gateway.builder.PathParameterBuilder;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * Takes a list of service parameters and appends together a string of
 * path entries. Operates on service parameters with “in” field
 * value of “PATH”.
 *
 */
@Service
public class PathParameterBuilderImpl implements PathParameterBuilder {

  @Override
  public String build(List<ServiceParameter> serviceParameters) {
    StringBuffer path = new StringBuffer();
    serviceParameters.stream().filter(serviceParameter -> serviceParameter.getIn().equals(PATH)).forEach(serviceParameter -> {
      path.append("/" ) ;
      path.append(serviceParameter.getValue()) ;
    });
    return path.toString();
  }
}

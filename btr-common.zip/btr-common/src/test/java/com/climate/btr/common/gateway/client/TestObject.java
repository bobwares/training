package com.climate.btr.common.gateway.client;

public class TestObject {

  private String test;

  public String getTest() {
    return test;
  }

  public void setTest(String test) {
    this.test = test;
  }
}

package com.climate.btr.common.converter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.Map;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@JsonDeserialize(builder = Dealerships.DealershipsBuilder.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@EqualsAndHashCode
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Getter
public class Dealerships {

  Map<String,String> dealerships;

  @JsonPOJOBuilder(withPrefix = "")
  public static final class DealershipsBuilder {}



}

package com.climate.btr.common.gateway.client;

import static com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum.HEADER;
import static com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum.PATH;
import static com.climate.btr.common.gateway.http.HttpHeaderKeyEnum.X_AUTHENTICATED_USER_ID;
import static com.climate.btr.common.gateway.http.HttpHeaderKeyEnum.X_HTTP_REQUEST_ID;
import static com.climate.btr.common.gateway.http.HttpHeaderKeyEnum.X_USER_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.climate.btr.common.converter.ObjectConverter;
import com.climate.btr.common.gateway.builder.HttpHeaderBuilder;
import com.climate.btr.common.gateway.builder.ServiceResourcePathBuilder;
import com.climate.btr.common.gateway.client.impl.ServiceGatewayImpl;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

class ServiceGatewayTest {

  @Mock
  private RestResponseValidator restResponseValidator;

  @Mock
  private ObjectConverter objectConverter;

  @Mock
  private RestClient restClient;

  @Mock
  private HttpHeaderBuilder httpHeaderBuilder;

  @Mock
  private ServiceResourcePathBuilder serviceResourcePathBuilder;

  private String SERVICE_NAME="testService";

  @BeforeEach
  void setup()  {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  void testPost() {

    String serviceName = "TEST_SERVICE";
    List<ServiceParameter> serviceParameters = new ArrayList<>();

    serviceParameters.add(ServiceParameter.builder()
        .in(HEADER)
        .name("x-http-id")
        .required(true)
        .type("string")
        .value("12345")
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(PATH)
        .name("field-id")
        .required(true)
        .type("string")
        .value("12345")
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(PATH)
        .name("prescription-id")
        .required(true)
        .type("string")
        .value("56789")
        .build());

    HttpHeaders httpHeaders = getHeaders("TEST_SERVICE", "TEST_ID");

    when(httpHeaderBuilder.build(anyString(), any())).thenReturn(httpHeaders);

    ServiceGateway serviceGateway = new ServiceGatewayImpl(
        SERVICE_NAME,
        restResponseValidator,
        objectConverter,
        restClient,
        serviceResourcePathBuilder,
        httpHeaderBuilder
    );

    ResponseEntity<String> responseEntity = new ResponseEntity<String>( "{\"test\":\"TEST\"}", HttpStatus.OK);
    when(restClient.post(anyString(), any(HttpHeaders.class), anyString(), any())).thenReturn(responseEntity);

    when(serviceResourcePathBuilder.build(any(), any(), any())).thenReturn("/test");

    TestObject testObject = new TestObject();
    testObject.setTest("TEST");

    given(objectConverter.jsonToObject(anyString(), any())).willReturn(Optional.ofNullable(testObject));


    TestObject response = serviceGateway.post(
        "test/url",
        "TestObject Data",
        TestObject.class,
        serviceParameters).get();


   assertEquals(response.getTest(), "TEST");
  }

  private HttpHeaders getHeaders(String serviceName, String userId) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(APPLICATION_JSON);
    headers.add(SERVICE_NAME, serviceName);
    headers.add(ACCEPT, APPLICATION_JSON_VALUE);
    headers.add(X_HTTP_REQUEST_ID.getValue(), MDC.get(X_HTTP_REQUEST_ID.getValue()));

    if (!StringUtils.isEmpty(userId)) {
      headers.add(X_USER_ID.getValue(), userId);
      headers.add(X_AUTHENTICATED_USER_ID.getValue(), userId);
    }
    return headers;
  }
}
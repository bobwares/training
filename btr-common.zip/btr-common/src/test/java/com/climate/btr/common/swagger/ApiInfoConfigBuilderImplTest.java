package com.climate.btr.common.swagger;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.swagger.exception.ApiInfoException;
import com.climate.btr.common.swagger.impl.ApiInfoConfigBuilderImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import springfox.documentation.service.ApiInfo;

class ApiInfoConfigBuilderImplTest {

  private static final String TEST_API_INFO = "this is a test";

  @Test
  void build() {

    Registry<String> registry = new Registry<>();
    registry.put("apiInfo", TEST_API_INFO);

    ApiInfoConfigBuilder apiInfoConfigBuilder = new ApiInfoConfigBuilderImpl(registry);
    final ApiInfo apiInfo = apiInfoConfigBuilder.build();
    assertEquals(apiInfo.getDescription(),TEST_API_INFO) ;
  }

  @Test
  void exceptionThrown() {
    Assertions.assertThrows(ApiInfoException.class, () -> {
      Registry<String> registry = new Registry<>();
      registry.put("wrong value", TEST_API_INFO);

      ApiInfoConfigBuilder apiInfoConfigBuilder = new ApiInfoConfigBuilderImpl(registry);
      apiInfoConfigBuilder.build();
    });
  }
}
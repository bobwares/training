package com.climate.btr.common.gateway.builder;


import static com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum.QUERY;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.climate.btr.common.gateway.builder.impl.QueryParameterBuilderImpl;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.ArrayList;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.util.MultiValueMap;


class QueryParameterBuilderTest {

  @Test
  void testBuild() {

    List<ServiceParameter> serviceParameters = new ArrayList<>();

    serviceParameters.add(ServiceParameter.builder()
        .in(QUERY)
        .name("field-id")
        .required(true)
        .type("string")
        .value("12345")
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(QUERY)
        .name("prescription-id")
        .required(true)
        .type("string")
        .value("56789")
        .build());


    QueryParameterBuilder queryParameterBuilder = new QueryParameterBuilderImpl();
    MultiValueMap<String, String> queryParameters = queryParameterBuilder.build(serviceParameters);
    assertNotNull(queryParameters);
  }

}
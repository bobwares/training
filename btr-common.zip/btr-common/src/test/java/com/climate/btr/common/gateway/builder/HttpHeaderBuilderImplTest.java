package com.climate.btr.common.gateway.builder;

import static com.climate.btr.common.gateway.http.ClimateHttpHeaderConstant.X_HTTP_CALLER_ID;
import static com.climate.btr.common.gateway.http.ClimateHttpHeaderConstant.X_HTTP_REQUEST_ID;
import static com.climate.btr.common.gateway.http.HttpHeaderKeyEnum.REQUEST_ID_PREFIX;
import static com.climate.btr.common.gateway.http.HttpHeaderKeyEnum.TALUS_OUTGOING_CALLER_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


import com.climate.btr.common.gateway.builder.impl.HttpHeaderBuilderImpl;
import com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;


class HttpHeaderBuilderImplTest {

  @Test
  private void testBuild() {

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(APPLICATION_JSON);
    headers.add(ACCEPT, APPLICATION_JSON_VALUE);
    headers.add(X_HTTP_REQUEST_ID, REQUEST_ID_PREFIX.getValue() + System.currentTimeMillis());
    headers.add(X_HTTP_CALLER_ID, TALUS_OUTGOING_CALLER_ID.getValue());

    HttpHeaderBuilder httpHeaderBuilder = new HttpHeaderBuilderImpl(headers);

    List<ServiceParameter> serviceParameters = new ArrayList<>();

    serviceParameters.add(ServiceParameter.builder()
        .in(ServiceParameterTypeEnum.HEADER)
        .name("HEADER_NAME_1")
        .value("HEADER_NAME_1_VALUE")
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(ServiceParameterTypeEnum.HEADER)
        .name("HEADER_NAME_2")
        .value("HEADER_NAME_2_VALUE")
        .build());

    HttpHeaders httpHeaders = httpHeaderBuilder.build("TEST_SERVICE", serviceParameters);
    assertEquals(httpHeaders.size(), 7);
    assertEquals(httpHeaders.get("HEADER_NAME_1").get(0),"HEADER_NAME_1_VALUE" );

  }
}
package com.climate.btr.common.swagger;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.climate.btr.common.config.CommonWeb;
import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.registry.exception.RegistryEntryNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@CommonWeb
class OperationBuilderPluginImplIT {

  @Autowired
  private Registry<String> apiDescriptionRegistry;

  @Test
  void apply() {
    final String apiInfo = apiDescriptionRegistry.get("apiInfo").orElseThrow(RegistryEntryNotFoundException::new);
    assertTrue(apiInfo.length() > 0);

  }

}
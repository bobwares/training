package com.climate.btr.common.template;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;


import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.template.model.JsonTemplateDefinition;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Optional;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;

public class TemplateRegistryTest {

//  @Mock
//  private ApplicationContext applicationContext;
//
//  @Mock
//  Resource resource;
//
//  @Mock
//  private InputStream inputStream;
//
//
//  @BeforeMethod
//  public void setup()  {
//    MockitoAnnotations.initMocks(this);
//  }
//
//  @Test
//  public void get() throws IOException {
//    given(applicationContext.getResource(anyString())).willReturn(resource);
//    given(resource.getInputStream()).willReturn(inputStream);
//    Registry<JsonTemplateDefinition> templateRegistry = new Registry<JsonTemplateDefinition>();
//    JsonTemplateDefinition jsonTemplateDefinition = JsonTemplateDefinition.builder().key("test").path("").build();
//
//    templateRegistry.put("test", jsonTemplateDefinition);
//    templateRegistry.setApplicationContext(applicationContext);
//
//    Optional<InputStreamReader> optional = templateRegistry.get("test");
//    Assert.assertNotNull(optional.get());
//  }
//
//
//  @Test
//  public void getCouldNotFindTemplate()  {
//    TemplateRegistry templateRegistry = new TemplateRegistry();
//    templateRegistry.setApplicationContext(applicationContext);
//
//    Optional<InputStreamReader> optional = templateRegistry.get("test");
//    Assert.assertFalse(optional.isPresent());
//  }
//
//
//  @Test
//  public void getIOException() throws IOException {
//    given(applicationContext.getResource(anyString())).willReturn(resource);
//    given(resource.getInputStream()).willThrow(new IOException());
//
//    TemplateRegistry templateRegistry = new TemplateRegistry();
//    templateRegistry.setApplicationContext(applicationContext);
//
//    JsonTemplateDefinition jsonTemplateDefinition = JsonTemplateDefinition.builder().key("test").path("").build();
//    templateRegistry.put("test", jsonTemplateDefinition);
//
//    Optional<InputStreamReader> optional = templateRegistry.get("test");
//    Assert.assertFalse(optional.isPresent());
//  }
}
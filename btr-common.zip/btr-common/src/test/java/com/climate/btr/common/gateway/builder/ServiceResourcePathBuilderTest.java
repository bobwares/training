package com.climate.btr.common.gateway.builder;

import static com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum.PATH;
import static com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum.QUERY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.climate.btr.common.gateway.builder.impl.PathParameterBuilderImpl;
import com.climate.btr.common.gateway.builder.impl.QueryParameterBuilderImpl;
import com.climate.btr.common.gateway.builder.impl.ServiceResourcePathBuilderImpl;
import com.climate.btr.common.gateway.discovery.DiscoveryServiceClient;
import com.climate.btr.common.gateway.exception.ServiceGatewayException;
import com.climate.btr.common.gateway.model.ServiceParameter;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;


public class ServiceResourcePathBuilderTest {

  @Mock
  PathParameterBuilder pathParameterBuilder;

  @Mock
  QueryParameterBuilder queryParameterBuilder;

  @Mock
  DiscoveryServiceClient discoveryServiceClient;

  @Test
  public void testBuild() {

    MockitoAnnotations.initMocks(this);

    String serviceName = "TEST_SERVICE";

    List<ServiceParameter> serviceParameters = new ArrayList<>();
    serviceParameters.add(ServiceParameter.builder()
        .in(QUERY)
        .name("activity-prefix")
        .value("PLANTING")
        .required(true)
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(QUERY)
        .name("primary-only")
        .value("false")
        .required(true)
        .build());
    serviceParameters.add(ServiceParameter.builder()
        .in(PATH)
        .name("field-id")
        .value("12345")
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(PATH)
        .name("prescription-id")
        .required(true)
        .value("56789")
        .build());

    PathParameterBuilder pathParameterBuilder = new PathParameterBuilderImpl();

    QueryParameterBuilder queryParameterBuilder = new QueryParameterBuilderImpl();

    when(discoveryServiceClient.getHost(anyString())).thenReturn(java.util.Optional.of("host"));

    ServiceResourcePathBuilder serviceResourcePathBuilder = new ServiceResourcePathBuilderImpl(discoveryServiceClient, pathParameterBuilder,  queryParameterBuilder);

    String serviceResourcePath = serviceResourcePathBuilder.build(serviceName, "test", serviceParameters);
    assertNotNull(serviceResourcePath);
  }
}
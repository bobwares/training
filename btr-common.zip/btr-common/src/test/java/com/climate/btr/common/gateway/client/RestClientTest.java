package com.climate.btr.common.gateway.client;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;

import com.climate.btr.common.gateway.client.impl.RestClientImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


class RestClientTest {

  @Mock
  private RestTemplate restTemplate;

  @Test
  void testPost() {
    MockitoAnnotations.initMocks(this);
    HttpHeaders headers = new HttpHeaders();
    headers.add("mockHeader", "mockId");
    HttpEntity<String> httpEntity = new HttpEntity<>("test", headers);
    ResponseEntity<String> responseEntity = new ResponseEntity<>("test", HttpStatus.ACCEPTED);
    given(restTemplate.exchange(anyString(), eq(HttpMethod.POST), eq(httpEntity), eq(String.class))).willReturn(responseEntity);
    RestClient restClient = new RestClientImpl(restTemplate);
    ResponseEntity<String> responseEntity2 = restClient.post("serviceName", headers,"url", "test");
    assertNotNull(responseEntity2);
  }
}
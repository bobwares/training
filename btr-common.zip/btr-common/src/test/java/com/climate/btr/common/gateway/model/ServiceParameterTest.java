package com.climate.btr.common.gateway.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.climate.btr.common.gateway.builder.impl.ServiceParameterTypeEnum;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class ServiceParameterTest {

  @Test
  void test() {

    List<ServiceParameter> serviceParameters = new ArrayList<>();

    serviceParameters.add(ServiceParameter.builder()
        .in(ServiceParameterTypeEnum.HEADER)
        .name("HEADER_NAME_1")
        .value("HEADER_NAME_1_VALUE")
        .build());

    serviceParameters.add(ServiceParameter.builder()
        .in(ServiceParameterTypeEnum.HEADER)
        .name("HEADER_NAME_2")
        .value("HEADER_NAME_2_VALUE")
        .build());

    ServiceParameter serviceParameter = ServiceParameter.getServiceParameter(serviceParameters, "HEADER_NAME_1");
    assertNotNull(serviceParameter);
    assertEquals(serviceParameter.getName(),"HEADER_NAME_1");
  }


}
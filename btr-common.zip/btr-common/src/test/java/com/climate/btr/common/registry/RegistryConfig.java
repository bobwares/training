package com.climate.btr.common.registry;

import com.climate.btr.common.converter.ObjectConverter;
import com.climate.btr.common.registry.impl.RegistryDataReaderImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RegistryConfig {

  @Bean
  public RegistryDataReader<RegistryDataReaderTestObject> resourceDefinitionResourceMapper(ObjectConverter objectMapper) {
    return new RegistryDataReaderImpl<>(objectMapper, RegistryDataReaderTestObject.class);
  }


}

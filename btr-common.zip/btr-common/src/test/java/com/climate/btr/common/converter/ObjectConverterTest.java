package com.climate.btr.common.converter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.climate.btr.common.CommonApplication;
import com.fasterxml.jackson.databind.JsonNode;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.rules.TemporaryFolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Slf4j
class ObjectConverterTest {

  @Autowired
  ObjectConverter objectConverter;

  @Test
  void loadResourceToObject() {
    Dealerships dealerships = objectConverter.loadResourceToObject("object-converter/dealerships.json", Dealerships.class).orElseThrow(ObjectConverterException::new);
    assertEquals(dealerships.getDealerships().size(), 5);
    assertEquals(dealerships.getDealerships().get("KRUGER_1"),"001J0000022qjo8IAA" );
  }

  @Test
  void loadFileToObject() throws IOException {
    String filePath;
    TemporaryFolder folder= new TemporaryFolder();
    String jsonString = "{\"test\":\"value\"}";
    BufferedWriter writer;

    folder.create();
    File createdFile= folder.newFile("temp.json");
    filePath = createdFile.getPath();
    writer = new BufferedWriter( new FileWriter( createdFile));
    writer.write( jsonString);
    writer.close();

    JsonNode jsonNode = objectConverter.loadFileToObject(filePath, JsonNode.class).orElseThrow(ObjectConverterException::new);
    assertNotNull(jsonNode);
  }

  @Test
  void loadResourceToMap() {
    Map<String, String> dealershipsMap = objectConverter.loadResourceToObject("object-converter/dealershipsMap.json", Map.class).orElseThrow(ObjectConverterException::new);
    assertEquals(dealershipsMap.size(), 5);
    assertEquals(dealershipsMap.get("KRUGER_1"),"001J0000022qjo8IAA" );
  }

  @Test
  void mapToJson() {

    Map<String, Object> map = new HashMap<>();
    map.put("userId", "12345");

    Optional<JsonNode> optional = objectConverter.mapToJson(map);
    assertNotNull(optional);
  }

}
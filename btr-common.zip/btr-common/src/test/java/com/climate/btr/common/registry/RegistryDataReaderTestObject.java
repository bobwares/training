package com.climate.btr.common.registry;

public class RegistryDataReaderTestObject {

  String stringValue;

  int anInt;

  public String getStringValue() {
    return stringValue;
  }

  public void setStringValue(String stringValue) {
    this.stringValue = stringValue;
  }

  public int getAnInt() {
    return anInt;
  }

  public void setAnInt(int anInt) {
    this.anInt = anInt;
  }
}

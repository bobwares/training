package com.climate.btr.common.template;

import com.climate.btr.common.objectcache.JsonTemplateCache;
import com.climate.btr.common.converter.ObjectConverter;
import com.fasterxml.jackson.databind.JsonNode;
import java.io.InputStreamReader;
import org.junit.Before;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class JsonNodeRegistryTest {

  @Mock
  private ObjectConverter objectConverter;

  @Mock
  private JsonTemplateCache jsonTemplateCache;

  @Mock
  private JsonNode jsonNode;

  @Mock
  private InputStreamReader inputStreamReader;

  @Before
  public void setup()  {
    MockitoAnnotations.initMocks(this);
  }
//
//  @Test
//  public void get() throws IOException {
//    given(templateRegistry.get("testTemplate")).willReturn(Optional.ofNullable(inputStreamReader));
//    given(objectConverter.jsonToObject(inputStreamReader, JsonNode.class)).willReturn(Optional.ofNullable(jsonNode));
//    JsonNodeRegistry jsonNodeRegistry = new JsonNodeRegistry(objectConverter, templateRegistry);
//    Optional<JsonNode> optional = jsonNodeRegistry.get("testTemplate");
//    Assert.assertNotNull(optional.get());
//  }
//
//  @Test
//  public void getJsonNodeExists() throws IOException {
//    given(templateRegistry.get("testTemplate")).willReturn(Optional.ofNullable(inputStreamReader));
//    given(objectConverter.jsonToObject(inputStreamReader, JsonNode.class)).willReturn(Optional.ofNullable(jsonNode));
//    JsonNodeRegistry jsonNodeRegistry = new JsonNodeRegistry(objectConverter, templateRegistry);
//    Optional<JsonNode> optional = jsonNodeRegistry.get("testTemplate");
//    Assert.assertNotNull(optional.get());
//    Optional<JsonNode> optional2 = jsonNodeRegistry.get("testTemplate");
//    AssertJUnit.assertEquals(optional.get(), optional2.get());
//  }
//
//  @Test(expectedExceptions = ObjectConverterException.class)
//  public void getTemplateNotFound() {
//    given(templateRegistry.get("testTemplate")).willReturn(Optional.ofNullable(null));
//    JsonNodeRegistry jsonNodeRegistry = new JsonNodeRegistry(objectConverter, templateRegistry);
//    JsonNode jsonNode =  jsonNodeRegistry.get("testTemplate").orElseThrow(ObjectConverterException::new);
//  }
//
//  @Test(expectedExceptions = ObjectConverterException.class)
//  public void getMapperException() throws IOException {
//    given(templateRegistry.get("testTemplate")).willReturn(Optional.ofNullable(inputStreamReader));
//    given(objectConverter.jsonToObject(inputStreamReader, JsonNode.class)).willThrow(new IOException());
//    JsonNodeRegistry jsonNodeRegistry = new JsonNodeRegistry(objectConverter, templateRegistry);
//    JsonNode jsonNode =  jsonNodeRegistry.get("testTemplate").orElseThrow(ObjectConverterException::new);
//  }
}
package com.climate.btr.common.registry;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.climate.btr.common.registry.exception.RegistryDataReaderException;
import com.climate.btr.common.registry.exception.RegistryEntryNotFoundException;
import com.climate.btr.common.swagger.registry.mapper.ApiDescriptionResourceMapper;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RegistryTest {

  Registry<String> registry;

  @BeforeEach
  public void setup() {
    registry = new Registry<>();
    registry.put("test", "test");
  }

  @Test
  void get() {
    final Optional<String> test = registry.get("test");
    assertEquals(test.get(),"test");
  }

  @Test
  void put() {
    registry.put("test2", "test2");
    assertEquals(registry.size(),2);
  }

  @Test
  void size() {
    assertEquals(registry.size(),1);
  }

  @Test
  void keySet() {
    final Set<String> keySet = registry.keySet();
    assertEquals(keySet.size(),1);
    assertTrue(keySet.iterator().hasNext());
    assertEquals(keySet.iterator().next(),"test");
  }

  @Test
  void exceptionThrown() {
    Assertions.assertThrows(RegistryEntryNotFoundException.class, () -> {
      String test = registry.get("missing").orElseThrow(RegistryEntryNotFoundException::new);
     });
  }
}
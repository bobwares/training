package com.climate.btr.common.registry;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.climate.btr.common.registry.impl.ResourceLoaderImpl;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.Resource;

class RegistryLoaderTest {

	@Test
  void loader() {
    ResourceLoader resourceLoader = new ResourceLoaderImpl();
    final Map<String, Resource> resourceMap = resourceLoader.load("swagger", "md");
    assertNotNull(resourceMap);
    assertEquals(4, resourceMap.size());
	}

}



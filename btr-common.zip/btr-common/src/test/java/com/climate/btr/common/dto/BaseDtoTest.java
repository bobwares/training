package com.climate.btr.common.dto;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import org.junit.jupiter.api.Test;

class BaseDtoTest {

  @Test
  void toStringTest() throws IOException {
    BaseDtoTestObject baseDto = new BaseDtoTestObject();
    baseDto.setIntValue(1);
    baseDto.setStringValue("StringValue");
    final String jsonString = baseDto.toString();

    ObjectMapper mapper = new ObjectMapper();
    JsonNode actualObj = mapper.readTree(jsonString);
    assertEquals("StringValue", actualObj.get("stringValue").asText());
    assertEquals(1, actualObj.get("intValue").asInt());
  }

  @Test
  void toJson() throws IOException {
    BaseDtoTestObject baseDto = new BaseDtoTestObject();
    baseDto.setIntValue(1);
    baseDto.setStringValue("StringValue");
    final String jsonString = baseDto.toJson();

    ObjectMapper mapper = new ObjectMapper();
    JsonNode actualObj = mapper.readTree(jsonString);
    assertEquals("StringValue", actualObj.get("stringValue").asText());
    assertEquals(1, actualObj.get("intValue").asInt());
  }
}
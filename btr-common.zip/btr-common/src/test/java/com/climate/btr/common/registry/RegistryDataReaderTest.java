package com.climate.btr.common.registry;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import com.climate.btr.common.converter.ObjectConverter;
import com.climate.btr.common.registry.exception.RegistryDataReaderException;
import com.climate.btr.common.swagger.registry.mapper.ApiDescriptionResourceMapper;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

class RegistryDataReaderTest {

  @Mock
  private Resource resource;

  private File file;

  @BeforeEach
  void setUp() throws IOException {
    MockitoAnnotations.initMocks(this);
    final ClassPathResource classPathResource = new ClassPathResource("swagger/apiInfo.md");
    file = classPathResource.getFile();

  }

  @Test
  void resourceToObject() throws IOException {
    InputStream inputStream = new FileInputStream(file);
    when(resource.getInputStream()).thenReturn(inputStream);
    RegistryDataReader<String> registryDataReader = new ApiDescriptionResourceMapper();
    final Optional<String> optional = registryDataReader.resourceToObject(resource);
    assertNotNull(optional.get());
  }

  @Test
  void resourceToObjectException() {
    Assertions.assertThrows(RegistryDataReaderException.class, () -> {
      when(resource.getFile()).thenReturn(null);
      RegistryDataReader<String> registryDataReader = new ApiDescriptionResourceMapper();
      String data = registryDataReader.resourceToObject(resource).orElseThrow(RegistryDataReaderException::new);
    });
  }

}
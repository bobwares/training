package com.climate.btr.common.converter;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.Resource;

class ResourceUtilsTest {

  @Test
  void findClasspathResources() throws IOException {
    final Map<String, Resource> resourceMap = ResourceUtils.findClasspathResources("resource-utils-test", "json");
    assertEquals(3, resourceMap.size());

    final Map<String, Resource> resourceMap2 = ResourceUtils.findClasspathResources("resource-utils-test", "txt");
    assertEquals(3, resourceMap2.size());

    final Map<String, Resource> resourceMap3 = ResourceUtils.findClasspathResources("resource-utils-test", "xyz");
    assertEquals(0, resourceMap3.size());
  }
}
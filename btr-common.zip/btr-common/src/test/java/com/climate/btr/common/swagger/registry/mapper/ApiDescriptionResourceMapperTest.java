package com.climate.btr.common.swagger.registry.mapper;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.climate.btr.common.registry.RegistryDataReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

class ApiDescriptionResourceMapperTest {

  @Mock
  private Resource resource;

  @Test
  void resourceToObject() throws IOException {
    MockitoAnnotations.initMocks(this);
    final ClassPathResource classPathResource = new ClassPathResource("swagger/apiInfo.md");
    File file = classPathResource.getFile();
    InputStream inputStream = new FileInputStream(file);
    when(resource.getInputStream()).thenReturn(inputStream);

    RegistryDataReader<String> resourceMapper = new ApiDescriptionResourceMapper();
    final Optional<String> optional = resourceMapper.resourceToObject(resource);
    assertTrue(optional.isPresent());
  }
}
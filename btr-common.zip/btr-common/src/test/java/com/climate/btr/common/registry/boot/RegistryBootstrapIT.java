package com.climate.btr.common.registry.boot;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.climate.btr.common.registry.Registry;
import com.climate.btr.common.registry.RegistryLoader;
import java.util.Collection;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class RegistryBootstrapIT {

  @Autowired
  private Collection<RegistryLoader> registryLoaders;

  @Autowired
  private Registry<String> apiDescriptionRegistry;

  @Test
  void afterPropertiesSet() {
    assertEquals(registryLoaders.size(),1);
    assertEquals(apiDescriptionRegistry.size(),4);
  }
}
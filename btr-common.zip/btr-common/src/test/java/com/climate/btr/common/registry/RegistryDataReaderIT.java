package com.climate.btr.common.registry;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.climate.btr.common.CommonApplication;
import com.climate.btr.common.registry.exception.RegistryDataReaderException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {CommonApplication.class, RegistryConfig.class})
class RegistryDataReaderIT {

  @Autowired
  ApplicationContext applicationContext;

  @Autowired
  private RegistryDataReader<RegistryDataReaderTestObject> registryDataReader;

  @Test
  void resourceToObject() throws Throwable {

    Resource resource = applicationContext.getResource("classpath:resource/registryDataRecord.json");
    final RegistryDataReaderTestObject registryDataReaderTestObject = registryDataReader.resourceToObject(resource)
        .orElseThrow(RegistryDataReaderException::new);

    assertNotNull(registryDataReaderTestObject);

  }
}
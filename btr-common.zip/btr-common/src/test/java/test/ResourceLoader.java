package test;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ResourceLoader {
  public static <T> T load(String path, Class<T> resultType)  {
    ClassLoader classLoader = ResourceLoader.class.getClassLoader();
    File file = new File(classLoader.getResource(path).getFile());
    try {
      ObjectMapper objectMapper = new ObjectMapper();
      objectMapper.registerModule(new JavaTimeModule());
      return objectMapper.readValue(file, resultType);

    } catch (IOException e) {
      log.error(e.getMessage());
      throw new ResourceLoaderException(e.getMessage());
    }

  }

  public static <T> void write(String path, Class<T> resultType)  {
    ClassLoader classLoader = ResourceLoader.class.getClassLoader();
    File file = new File(classLoader.getResource(path).getFile());
    try {
      new ObjectMapper().writeValue(file, resultType);

    } catch (IOException e) {
      log.error(e.getMessage());
      throw new ResourceLoaderException(e.getMessage());
    }

  }

  public static <T> T jsonToObject(String jsonString, Class<T> resultType) throws IOException {
    return new ObjectMapper()
        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).readValue(new ByteArrayInputStream(jsonString.getBytes()), resultType);
  }

}
